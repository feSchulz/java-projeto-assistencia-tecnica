package com.assitenciaTecnica.logos.controllers.security;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.DefaultSecurityFilterChain;

public class SecurityFilterChain {
    @Bean
    public DefaultSecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .cors(Customizer.withDefaults()) // usa o bean corsConfigurationSource
                .csrf(csrf -> csrf.disable())    // API JSON; CSRF atrapalha o preflight
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        .requestMatchers("/api/auth/v1/login", "/api/auth/v1/logout").permitAll()
                        .anyRequest().authenticated()
                );
        // ... resto (session, formLogin, jwt, etc.)

        return http.build();
    }
}
