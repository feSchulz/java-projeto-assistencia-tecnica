package com.assitenciaTecnica.logos.config;

public class SecurityConfig {
}
